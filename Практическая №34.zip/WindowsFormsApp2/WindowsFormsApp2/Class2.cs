﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Class2:Class1
    {
        public static double ploshad(int a)
        {
            return a * a;
        }

        public static double ploshad(int a, int b)
        {
            return a * b;
        }
        public static double ploshad(int a, int b, int c)
        {
            double p = (a * b * c) / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));

        }
        public static double ploshad(int a, int b, int c, int d)
        {
            return ((a + b) / 2) * (Math.Sqrt(c * c) - ((((b - a) * (b - a)) + (c * c) - (d * d)) / (2 * (b - a))) * ((((b - a) * (b - a)) + (c * c) - (d * d)) / (2 * (b - a))));
        }
        public static double ploshad (double r)
        {
            return 3.14 * r * r;
        }
    }
}
