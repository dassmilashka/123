﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "ПЛОЩАДИ";
        }
        public void vib()
        {
            if (radioButton1.Checked)
            {
                textBox1.Visible = true;
                textBox2.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                label1.Visible = true;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label1.Text = "сторона квадрата";
            }
            if (radioButton2.Checked)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = false;
                label4.Visible = false;
                label1.Text = "первая сторона прямоугольника";
                label2.Text = "вторая сторона прямоугольника";
                
            };
            if (radioButton3.Checked)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = false;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = false;
                label1.Text = "первая сторона треугольника";
                label2.Text = "вторая сторона треугольника";
                label3.Text = "третья сторона треугольника";
            };
            if (radioButton5.Checked)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label1.Text = "верхняя сторона трапеции";
                label2.Text = "нижняя сторона трапеции";
                label3.Text = "левая сторона трапеции";
                label4.Text = "правая сторона трапеции";
            };
            if (radioButton4.Checked)
            {
                textBox1.Visible = true;
                textBox2.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                label1.Visible = true;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label1.Text = "радиус";
            };
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            vib();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            vib();

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            vib();
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            vib();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            vib();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked)
                {
                    Class2.S = Class2.ploshad(Convert.ToInt32(textBox1.Text));
                    label6.Text = Convert.ToString(Class2.S);
                };
                if (radioButton2.Checked)
                {
                    Class2.S = Class2.ploshad(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text));
                    label6.Text = Convert.ToString(Class2.S);
                }
                if (radioButton3.Checked)
                {
                    Class2.S = Class2.ploshad(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text), Convert.ToInt32(textBox3.Text));
                    label6.Text = Convert.ToString(Class2.S);
                }
                if (radioButton5.Checked)
                {
                    Class2.S = Class2.ploshad(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text), Convert.ToInt32(textBox3.Text), Convert.ToInt32(textBox4.Text));
                    label6.Text = Convert.ToString(Class2.S);
                }
                if (radioButton4.Checked)
                {
                    Class2.S = Class2.ploshad(Convert.ToDouble(textBox1.Text));
                    label6.Text = Convert.ToString(Class2.S);
                };
                
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
            }
            catch
            {
                MessageBox.Show("фигня");
            }
            } 

        }
    }
